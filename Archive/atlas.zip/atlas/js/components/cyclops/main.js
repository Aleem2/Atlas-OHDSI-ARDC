define(function (require, exports) {
	
	var ko = require('knockout')
	
	var controlEditor = require('./components/control-editor');
	var priorEditor = require('./components/prior-editor');
});
